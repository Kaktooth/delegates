﻿using System;

namespace d4
{
    class Program
    {
        delegate void Del(double num);
        static void Main(string[] args)
        {
            Del d = Calculate1;
            d(1);
            d(2);
            d(3);
            Del d2 = Calculate2;
            d2(1);
            d2(2);
            d2(3);
            Del d3 = Calculate3;
            d3(1);
            d3(2);
            d3(3);

        }
        static void Calculate1(double num)
        {
            double sum = 0;
            for (int i = 1; i <= num; i++)
            {
                double n = 1 / Math.Pow(2,i );
                Console.WriteLine("number " + n);
                sum += n;
            }   
            
            Console.WriteLine($"Cумма ряду: {Math.Round(sum, 2)}");
        }
        static void Calculate2(double num)
        {
            double sum = 0;
            for (int i = 1; i <= num; i++)
            {
                double n = 1;
                if (i >= 2) { n = (double)1 / Factorial(i); }
                
                Console.WriteLine("number " + n);
                sum += n;
            }

            Console.WriteLine($"Cумма ряду: {Math.Round(sum, 2)}");
        }
        static void Calculate3(double num)
        {
            double sum = 0;
            for (int i = 1; i <= num; i++)
            {
                double n = 1 / Math.Pow(2, i);
                Console.WriteLine("number " + n);
                if (i % 2 == 0)
                {
                    sum -= n;
                }
                else
                {
                    sum += n;
                }
            }

            Console.WriteLine($"Cумма ряду: {Math.Round(sum, 2)}");
        }
        static int Factorial(int x)
        {
            if (x == 0)
            {
                return 1;
            }
            else
            {
                return x * Factorial(x - 1);
            }
        }
    }
}
