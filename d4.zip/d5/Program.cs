﻿using System;

namespace d5
{
    class Program
    {
        delegate float del(int x);
        static void Main(string[] args)
        {
            Console.WriteLine(" 0-- sqrt(abs(x))   1-- x ^ 3  2-- x + 3, 5");
            del[] d = new del[] { C1,C2,C3};
            int[] num = new int[] { 0, 1, 2 };
            while (true)
            {
                try
                {
                    int[] nums = Array.ConvertAll(Convert.ToString(Console.ReadLine()).Split(" "), int.Parse);
                    float result = d[nums[0]](nums[1]);
                    Console.WriteLine(result);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Помилка");
                }
            }
        }
        static float C1(int x)
        {
            return MathF.Sqrt(MathF.Abs((float)x));
        }
        static float C2(int x)
        {
            return MathF.Pow((float)x, 3);
        }
        static float C3(int x)
        {
            return (float)x + 3.5f;
        }
    }
}
