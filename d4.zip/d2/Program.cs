﻿using System;
using System.Threading;

namespace d2
{
    delegate int Completed(int secCompleted);
    class Program
    {
        static void Main(string[] args)
        {
            Timer t = new Timer(2);
            t.Start();
        }
    }
    class Timer
    {
        private int sec { get; set; }
        private int t { get; set; }
     
        public Timer(int t)
        {
            this.sec = 1;
            this.t = t;
        }
       
        public void Start()
        {
            Completed c = CompletedSec;
            while (true)
            {
                Thread.Sleep(1000);
                sec++;
                c(t);
            }
        }
        public int CompletedSec(int sec)
        {
            if(this.sec % sec == 0)
            {
                Console.WriteLine("Completed " + this.sec);
            }
            return sec;
        }
       
    }
}
