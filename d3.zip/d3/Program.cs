﻿using System;

namespace d3
{
    class Program
    {
        delegate void Del(int num);
        static void Main(string[] args)
        {
            int[] array = new int[] { 1, 2, 32, 4, 7, 8, 2, 9, 23, 7, 23, 12, 1, 24, 28, 3, 6 };
            Del d = Check;
            foreach (var num in array)
            {
                d(num);
            }

        }
        public static void Check(int num)
        {
            if(num % 3==0 || num % 7 == 0)
            {
                Console.WriteLine(num + " Checked");
            }
        }
    }
}
