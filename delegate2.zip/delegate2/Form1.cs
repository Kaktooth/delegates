﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace delegate2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        delegate void Del(object sender, EventArgs e);

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.Opacity == 0.1f) this.Opacity = 1f;
            else this.Opacity = 0.1f; 
        }


        private void button2_Click(object sender, EventArgs e)
        {
            if (this.BackColor == Color.Gray) this.BackColor = Color.White;
            else this.BackColor = Color.Gray;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello World!");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Я супермегакнопка,\nі цього мене не позбавиш!");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox1.Checked)
                this.button4.Click += new EventHandler(this.button1_Click);
            else
                this.button4.Click -= new EventHandler(this.button1_Click);
        }
        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox1.Checked)
                this.button4.Click += new EventHandler(this.button2_Click);
            else
                this.button4.Click -= new EventHandler(this.button2_Click);
        }
        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox1.Checked)
                this.button4.Click += new EventHandler(this.button3_Click);
            else
                this.button4.Click -= new EventHandler(this.button3_Click);
        }
    }
}
